@extends('layouts.app')

@section('title')
    Delivery Schedule
@endsection

@section('css')
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.14.1/themes/base/jquery-ui.css">
    <style>
        #suggestions {
            position: absolute;
            z-index: 1050;
            max-height: 250px;
            overflow-y: auto;
        }
        
        #shop_suggestions {
            position: absolute;
            z-index: 1050;
            max-height: 250px;
            overflow-y: auto;
        }

        #shop_address_suggestions {
            position: absolute;
            z-index: 1050;
            max-height: 250px;
            overflow-y: auto;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css">
@endsection

@section('content')
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <div class="breadcrumb-title pe-3">Delivery Schedule</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item">
                        <a href="{{ route('dashboard') }}">
                            <i class="bx bx-home-alt"></i>
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Delivery Schedule</li>
                </ol>
            </nav>
        </div>
        <div class="ms-auto">
            <div class="d-flex align-items-center gap-2 justify-content-lg-end">
                <a class="btn btn-primary px-4" href="{{ route('delivery-schedule.index') }}">
                    <i class="fadeIn animated bx bx-arrow-back"></i>Back
                </a>
            </div>
        </div>
    </div>
    <!--end breadcrumb-->

    <form class="needs-validation" action="{{ route('delivery-schedule.update', $delivery_Schedule->id) }}" method="post"
        novalidate enctype="multipart/form-data">
        @csrf
        @method('PUT')


        {{-- <input type="hidden" name="shop_ids" id="shop_ids" value="{{ implode(',', $selectedShops) }}"> --}}
        <div class="row">
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header text-center">Edit Delivery Schedule</div>
                    <div class="card-body">

                        <div class="row">
                            <div class="mb-3 col-md-4">
                                <label class="form-label" for="delivery_date">Delivery Date <span
                                        class="text-danger">*</span></label>
                                <input type="date" class="form-control"
                                    value="{{ old('delivery_date', $delivery_Schedule->delivery_date) }}"
                                    name="delivery_date" id="delivery_date" placeholder="Enter date" required>
                                <div class="valid-feedback">Looks good!</div>
                                <div class="invalid-feedback">Please enter shop name.</div>
                            </div>

                            <div class="mb-3 col-md-4">
                                <label class="form-label" for="driver_id">Choose Driver <span
                                        class="text-danger">*</span></label>
                                <select class="form-select single-select-field" name="driver_id" id="driver_id" required>
                                    <option value="" selected disabled>Select Driver</option>
                                    @foreach ($drivers as $driver)
                                        <option value="{{ $driver->id }}"
                                            {{ old('driver_id', $delivery_Schedule->driver_id) == $driver->id ? 'selected' : '' }}>
                                            {{ $driver->name }}</option>
                                    @endforeach
                                </select>
                                <div class="valid-feedback">Looks good!</div>
                                <div class="invalid-feedback">Please enter shop contact person name.</div>
                            </div>

                            <!--<div class="mb-3 col-md-4">-->
                            <!--    <label class="form-label" for="vehicle_id">Choose Vehicle <span-->
                            <!--            class="text-danger">*</span></label>-->
                            <!--    <select class="form-select single-select-field" name="vehicle_id" id="vehicle_id" required>-->
                            <!--        <option value="" selected disabled>Select Vehicle</option>-->
                            <!--        @foreach ($vehicles as $vehicle)-->
                            <!--            <option value="{{ $vehicle->id }}"-->
                            <!--                {{ old('vehicle_id', $delivery_Schedule->vehicle_id) == $vehicle->id ? 'selected' : '' }}>-->
                            <!--                {{ $vehicle->name }}( {{ $vehicle->vehicle_number }} )</option>-->
                            <!--        @endforeach-->
                            <!--    </select>-->
                            <!--    <div class="valid-feedback">Looks good!</div>-->
                            <!--    <div class="invalid-feedback">Please enter a valid shop address.</div>-->
                            <!--</div>-->

                            {{-- <div class="mb-3">
                                <label class="form-label" for="shop">Choose Shops<span class="text-danger">*</span></label>
                                <select class="form-select single-select-field" id="shop" name="shop" data-placeholder="Choose anything">
                                    <option value="" selected>Select Shops</option>
                                    @foreach ($shops as $shop)
                                        <option value="{{ $shop->id }}">{{ $shop->shop_name }}</option>
                                    @endforeach
                                </select>
                                <div class="valid-feedback">Looks good!</div>
                                <div class="invalid-feedback">Please enter start point.</div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Selected Shops</label>
                                <ul id="sortable-bus-stops" class="list-group"></ul>
                            </div> --}}

                            <div class="mb-3">
                                <label class="form-label">Search Shop Name</label>
                                <a class="btn view-map border" data-bs-toggle="modal" data-bs-target="#quickShopAddModal">
                                    <i class="text-primary" data-feather="plus"></i>
                                </a>
                                <input type="text" class="form-control" id="search_shop_name"
                                    placeholder="Enter shop name">
                                <div id="suggestions" class="list-group position-absolute w-100 z-index-3"></div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Sorting Shops Location</label>


                                <ul id="sortable-shop-location" class="list-group">
                                    @foreach ($selectedShops as $index => $item)
                                        @php
                                            $shop = $item->shop;
                                        @endphp
                                        @if ($shop)
                                            <li class="list-group-item d-flex align-items-center"
                                                data-id="{{ $shop->id }}">
                                                <span class="sl-no">{{ $loop->iteration }}. </span>
                                                <span class="ms-2 flex-grow-1">{{ $shop->shop_name }} -
                                                    {{ $shop->shop_address }}</span>
                                                <input type="hidden" name="shop_ids[]" value="{{ $shop->id }}">
                                                <input type="hidden" name="shop_names[]" value="{{ $shop->shop_name }}">
                                                <input type="hidden" name="shop_addresses[]"
                                                    value="{{ $shop->shop_address }}">
                                                <input type="hidden" name="shop_latitudes[]"
                                                    value="{{ $shop->shop_latitude }}">
                                                <input type="hidden" name="shop_longitudes[]"
                                                    value="{{ $shop->shop_longitude }}">
                                                <button type="button"
                                                    class="btn btn-danger btn-sm ms-2 remove-shop">❌</button>
                                                <span class="handle text-secondary ms-auto" style="cursor: grab;">☰</span>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>

                            </div>
                            <button type="button" class="btn btn-success mb-3" id="sortByNearestBtn">
                                Sort by Nearest Shop
                            </button>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="row">
                    <div class="card">
                        <div class="card-header text-center">Publish</div>
                        <div class="card-body">
                            {{-- <div class="mb-3">
                                <label class="form-label mb-3 d-flex">Status</label>
                                <div class="form-check form-check-inline">
                                    <input type="radio" id="customRadioInline1" name="is_visible" class="form-check-input" value="1" {{ check_uncheck($data->is_visible,1) }}>
                                    <label class="form-check-label" for="customRadioInline1">Active</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="radio" id="customRadioInline2" name="is_visible" class="form-check-input" value="0" {{ check_uncheck($data->is_visible,0) }}>
                                    <label class="form-check-label" for="customRadioInline2">Inactive</label>
                                </div>
                            </div> --}}
                            <div class="d-md-flex d-grid align-items-center gap-3">
                                <button type="submit" class="btn btn-grd-primary px-4 text-light">Submit</button>
                                {{-- <button type="reset" class="btn btn-grd-info px-4 text-light">Reset</button> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    
    
       <div class="modal fade" id="quickShopAddModal">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
            <div class="modal-content">
                <div class="modal-header border-bottom-0 bg-grd-primary py-2">
                    <h5 class="modal-title text-light">Company Add Form</h5>
                    <a href="javascript:;" class="primaery-menu-close" data-bs-dismiss="modal">
                        <i class="material-icons-outlined text-light">close</i>
                    </a>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <div class="card w-100">
                            <form action="" id="shopCreateForm" class="needs-validation" novalidate>
                                @csrf
                                <div class="card-body">

                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_name">Shop Name <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="{{ old('shop_name') }}"
                                                name="shop_name" id="shop_name" placeholder="Enter shop name" required>
                                            <div class="valid-feedback">Looks good!</div>
                                            <div class="invalid-feedback">Please enter shop name.</div>
                                            <div id="shop_suggestions"
                                                class="list-group position-absolute w-100 z-index-3">
                                            </div>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_contact_person_name">Shop Contact Person
                                                Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control"
                                                value="{{ old('shop_contact_person_name') }}"
                                                name="shop_contact_person_name" id="shop_contact_person_name"
                                                placeholder="Enter shop contact person name" required>
                                            <div class="valid-feedback">Looks good!</div>
                                            <div class="invalid-feedback">Please enter shop contact person name.</div>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_address">Shop Address <span
                                                    class="text-danger">*</span></label>
                                            <textarea name="shop_address" id="shop_address" class="form-control" placeholder="Enter shop address"
                                                id="shop_address" required>{{ old('shop_address') }}</textarea>
                                            <div class="valid-feedback">Looks good!</div>
                                            <div class="invalid-feedback">Please enter a valid shop address.</div>

                                            <div id="shop_address_suggestions"
                                                class="list-group position-absolute w-100 z-index-3"></div>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_contact_person_phone">Shop Contact Person
                                                Phone No.
                                                <span class="text-danger">*</span></label>
                                            <input type="tel" minlength="10" maxlength="10" pattern="[0-9]{10}"
                                                class="form-control" value="{{ old('shop_contact_person_phone') }}"
                                                name="shop_contact_person_phone" id="shop_contact_person_phone"
                                                placeholder="Enter shop contact person phone no." required>
                                            <div class="valid-feedback">Looks good!</div>
                                            <div class="invalid-feedback">Please enter shop contact person phone no.</div>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_latitude">Latitude</label>
                                            <input type="text" class="form-control"
                                                value="{{ old('shop_latitude') }}" name="shop_latitude"
                                                id="shop_latitude" placeholder="Enter latitude">
                                            <div class="valid-feedback">Looks good!</div>
                                            <div class="invalid-feedback">Please enter latitude.</div>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_longitude">Longitude</label>
                                            <input type="text" class="form-control"
                                                value="{{ old('shop_longitude') }}" name="shop_longitude"
                                                id="shop_longitude" placeholder="Enter longitude">
                                            <div class="valid-feedback">Looks good!</div>
                                            <div class="invalid-feedback">Please enter longitude.</div>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label" for="shop_longitude">Longitude</label>
                                            <div class="mb-3">
                                                <img class="img-thumbnail rounded me-2" id="blah" alt=""
                                                    width="200" src="" data-holder-rendered="true"
                                                    style="display: none;">
                                            </div>
                                            <div class="mb-0">
                                                <input class="form-control" name="image" type="file"
                                                    id="imgInp">

                                                <input type="hidden" name="shop_image_from_google"
                                                    id="shop_image_from_google">

                                                {{-- <img id="shop_preview" src="" alt="Shop Preview" class="img-thumbnail mt-2" style="max-width: 200px; display: none;"> --}}

                                            </div>
                                        </div>
                                    </div>

                                </div>
                             
                                <div class="d-flex">

                                    <button type="button" class="btn btn-grd-danger text-light "
                                        data-bs-dismiss="modal">Close</button>


                                    <button type="submit" id="submitBtn"
                                        class="btn btn-grd-primary px-4 mx-2 text-light">Submit</button>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection


@section('scripts')
    <script src="https://code.jquery.com/ui/1.14.1/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="{{ asset('assets/dashboard-assets/assets/plugins/select2/js/select2-custom.js') }}"></script>
    {{-- <script>
        $(document).ready(function() {
            let selectedShopIds = $("#shop_ids").val().split(",");

            // Populate selected shops on page load
            selectedShopIds.forEach(function(shopId) {
                if (shopId) {
                    let shopName = $("#shop option[value='" + shopId + "']").text();
                    if (shopName) {
                        $("#sortable-bus-stops").append(`
                            <li class="list-group-item d-flex justify-content-between align-items-center" data-id="${shopId}">
                                ${shopName}
                                <button class="btn btn-sm btn-danger remove-shop">Remove</button>
                            </li>
                        `);
                    }
                }
            });

            // Initialize sortable list
            $("#sortable-bus-stops").sortable({
                update: function(event, ui) {
                    updateShopIds();
                }
            });

            $("#shop").change(function() {
                let shopId = $(this).val();
                let shopName = $("#shop option:selected").text();

                if (shopId && $("#sortable-bus-stops li[data-id='" + shopId + "']").length === 0) {
                    $("#sortable-bus-stops").append(`
                        <li class="list-group-item d-flex justify-content-between align-items-center" data-id="${shopId}">
                            ${shopName}
                            <button class="btn btn-sm btn-danger remove-shop">Remove</button>
                        </li>
                    `);
                    updateShopIds();
                }
            });

            // Remove shop from list
            $(document).on("click", ".remove-shop", function() {
                $(this).parent().remove();
                updateShopIds();
            });

            // Update hidden input with sorted shop IDs
            function updateShopIds() {
                let shopIds = [];
                $("#sortable-bus-stops li").each(function() {
                    shopIds.push($(this).data("id"));
                });
                $("#shop_ids").val(shopIds.join(",")); 
            }
        });

    </script> --}}

    <script>
        let currentLat = null;
        let currentLng = null;

        $(document).ready(function() {
            const $input = $('#search_shop_name');
            const $suggestions = $('#suggestions');
            const $sortableList = $('#sortable-shop-location');

            // ✅ Step 1: Get user's current location
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    currentLat = position.coords.latitude;
                    currentLng = position.coords.longitude;
                    // console.log("User Location:", currentLat, currentLng);
                    // alert("Location captured: " + currentLat + ", " + currentLng);
                }, function() {
                    // alert("Failed to get location");
                });
            } else {
                // alert("Geolocation is not supported by this browser.");
            }

            // ✅ Step 2: Shop search autocomplete
            $input.on('input', function() {
                const query = $(this).val().trim();
                if (query.length < 2) {
                    $suggestions.empty().hide();
                    return;
                }

                $.get("{{ route('shop.search') }}", {
                    search: query
                }, function(response) {
                    $suggestions.empty().show();

                    if (response.length > 0) {
                        response.forEach(function(item) {
                            const $option = $(`
                            <a href="#" class="list-group-item list-group-item-action d-flex flex-column">
                                <div class="fw-bold">${item.shop_name}</div>
                                <small>${item.shop_address}</small>
                            </a>
                        `);

                            $option.data({
                                id: item.id,
                                name: item.shop_name,
                                address: item.shop_address,
                                lat: item.shop_latitude,
                                lng: item.shop_longitude
                            });

                            $suggestions.append($option);
                        });
                    } else {
                        $suggestions.append('<div class="list-group-item">No results found</div>');
                    }
                });
            });

            // ✅ Step 3: Add selected shop to list
            $suggestions.on('click', 'a', function(e) {
                e.preventDefault();
                const data = $(this).data();

                // Prevent duplicate
                if ($sortableList.find(`li[data-id="${data.id}"]`).length === 0) {
                    const $li = $(`
                    <li class="list-group-item d-flex align-items-center" data-id="${data.id}">
                        <span class="sl-no"></span>  
                        <span class="ms-2 flex-grow-1">${data.name} - ${data.address}</span>
                        <input type="hidden" name="shop_ids[]" value="${data.id}">
                        <input type="hidden" name="shop_names[]" value="${data.name}">
                        <input type="hidden" name="shop_addresses[]" value="${data.address}">
                        <input type="hidden" name="shop_latitudes[]" value="${data.lat}">
                        <input type="hidden" name="shop_longitudes[]" value="${data.lng}">
                        <button type="button" class="btn btn-danger btn-sm ms-2 remove-shop">❌</button>
                        <span class="handle text-secondary ms-auto" style="cursor: grab;">☰</span>
                    </li>
                `);

                    $sortableList.append($li);
                    updateShopSerialNumbers();
                }
                $input.val(''); 

                $suggestions.empty().hide();
            });

            // ✅ Step 4: Remove shop from list
            $(document).on('click', '.remove-shop', function() {
                $(this).closest('li').remove();
                updateShopSerialNumbers();
            });

            // ✅ Step 5: Sortable init
            $sortableList.sortable({
                handle: '.handle',
                update: function() {
                    setTimeout(updateShopSerialNumbers, 50);
                }
            }).disableSelection();

            function updateShopSerialNumbers() {
                $sortableList.find('li').each(function(index) {
                    $(this).find('.sl-no').text((index + 1) + ". ");
                });
            }

            // ✅ Step 6: Sort by Nearest Distance
            $('#sortByNearestBtn').on('click', function() {
                if (currentLat === null || currentLng === null) {
                    alert("User location not available yet.");
                    return;
                }

                function getDistance(lat1, lon1, lat2, lon2) {
                    const R = 6371;
                    const dLat = (lat2 - lat1) * Math.PI / 180;
                    const dLon = (lon2 - lon1) * Math.PI / 180;
                    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);
                    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                    return R * c;
                }

                const shopItems = $sortableList.children('li').map(function() {
                    const $li = $(this);
                    const lat = parseFloat($li.find('input[name="shop_latitudes[]"]').val());
                    const lng = parseFloat($li.find('input[name="shop_longitudes[]"]').val());
                    const distance = getDistance(currentLat, currentLng, lat, lng);
                    return {
                        element: $li,
                        distance
                    };
                }).get();

                shopItems.sort((a, b) => a.distance - b.distance);
                $sortableList.empty();
                shopItems.forEach(item => $sortableList.append(item.element));
                updateShopSerialNumbers();
                alert("Shop list sorted by nearest location.");
            });

            // Close suggestions when clicking outside
            $(document).on('click', function(e) {
                if (!$(e.target).closest('#search_shop_name, #suggestions').length) {
                    $suggestions.empty().hide();
                }
            });
        });
    </script>
    
    <script>
        $(document).ready(function() {

            $('#shopCreateForm').on('submit', function(e) {
                e.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: '{{ route('delivery-schedule.add_shop') }}',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        $('#submitBtn').prop('disabled', true).text('Saving...');
                    },
                    success: function(response) {
                        if (response.success) {
                            round_success_noti(response.message);
                            $('#shopCreateForm')[0].reset();
                            $('#quickShopAddModal').modal('hide');

                       
                        } else {
                            round_error_noti('Error: ' + response.message);
                        }
                    },
                    error: function(xhr) {
                        let errorMessage = 'An unexpected error occurred!';
                        if (xhr.responseJSON) {
                            if (typeof xhr.responseJSON.message === 'object') {
                                errorMessage = '';
                                $.each(xhr.responseJSON.message, function(key, value) {
                                    errorMessage += value[0] + "<br>";
                                });
                            } else if (typeof xhr.responseJSON.message === 'string') {
                                errorMessage = xhr.responseJSON.message;
                            }
                        }
                        round_error_noti(errorMessage);
                    },
                    complete: function() {
                        $('#submitBtn').prop('disabled', false).text('Submit');
                    }
                });
            });

        });
    </script>

    <script>
        const GOOGLE_MAPS_API_KEY = "{{ env('GOOGLE_MAPS_API_KEY') }}";
        $(document).ready(function() {
            // var apiKey = "AlzaSyC7RSr791vm_29LJiUOPJO-sLnBZg6qiGl";
            var apiKey = GOOGLE_MAPS_API_KEY;
            var $input = $('#shop_name');
            var $shop_suggestions = $('#shop_suggestions');

            $input.on('input', function() {
                var query = $(this).val().trim();
                if (query.length < 3) {
                    $shop_suggestions.empty().hide();
                    return;
                }

                $.get('https://maps.gomaps.pro/maps/api/place/textsearch/json', {
                    key: apiKey,
                    query: query
                }, function(response) {
                    $shop_suggestions.empty().show();

                    if (response.status === 'OK' && response.results.length > 0) {
                        response.results.forEach(function(item) {
                            var name = item.name || '';
                            var address = item.formatted_address || '';
                            var lat = item.geometry?.location?.lat || '';
                            var lng = item.geometry?.location?.lng || '';
                            var photoRef = item.photos?.[0]?.photo_reference || '';
                            var photoUrl = photoRef ?
                                `https://maps.gomaps.pro/maps/api/place/photo?maxwidth=400&photo_reference=${photoRef}&key=${apiKey}` :
                                '';

                            var $option = $(
                                '<a href="#" class="list-group-item list-group-item-action d-flex align-items-center"></a>'
                            );

                            if (photoUrl) {
                                $option.append(
                                    `<img src="${photoUrl}" class="me-2" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px;">`
                                );
                            }

                            $option.append(
                                `<div><div class="fw-bold">${name}</div><small>${address}</small></div>`
                            );
                            $option.data({
                                name,
                                address,
                                lat,
                                lng,
                                image: photoUrl
                            });
                            $shop_suggestions.append($option);
                        });
                    } else {
                        $shop_suggestions.append(
                            '<div class="list-group-item">No results found</div>');
                    }
                });
            });

            $shop_suggestions.on('click', 'a', function(e) {
                e.preventDefault();
                var data = $(this).data();

                $('#shop_name').val(data.name);
                $('#shop_address').val(data.address);
                $('#shop_latitude').val(data.lat);
                $('#shop_longitude').val(data.lng);

                // $('#shop_preview').attr('src', data.image || '').toggle(!!data.image);
                $('#blah').attr('src', data.image || '').toggle(!!data.image);
                $('#shop_image_from_google').val(data.image);
                $shop_suggestions.empty().hide();
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('#shop_name, #suggestions').length) {
                    $shop_suggestions.empty().hide();
                }
            });


            var $shop_address = $('#shop_address');
            var $address_suggestions = $('#address_suggestions');

            $shop_address.on('input', function() {
                var query = $(this).val().trim();
                if (query.length < 3) {
                    $address_suggestions.empty().hide();
                    return;
                }

                $.get('https://maps.gomaps.pro/maps/api/place/textsearch/json', {
                    key: apiKey,
                    query: query
                }, function(response) {
                    console.log(response);

                    $address_suggestions.empty().show();

                    if (response.status === 'OK' && response.results.length > 0) {
                        response.results.forEach(function(item) {
                            var name = item.name || '';
                            var address = item.formatted_address || '';
                            var lat = item.geometry?.location?.lat || '';
                            var lng = item.geometry?.location?.lng || '';
                            var photoRef = item.photos?.[0]?.photo_reference || '';
                            var photoUrl = photoRef ?
                                `https://maps.gomaps.pro/maps/api/place/photo?maxwidth=400&photo_reference=${photoRef}&key=${apiKey}` :
                                '';

                            var $option = $(
                                '<a href="#" class="list-group-item list-group-item-action d-flex align-items-center"></a>'
                            );

                            if (photoUrl) {
                                $option.append(
                                    `<img src="${photoUrl}" class="me-2" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px;">`
                                );
                            }

                            $option.append(
                                `<div><div class="fw-bold">${name}</div><small>${address}</small></div>`
                            );
                            $option.data({
                                name,
                                address,
                                lat,
                                lng,
                                image: photoUrl
                            });
                            $address_suggestions.append($option);
                        });
                    } else {
                        $address_suggestions.append(
                            '<div class="list-group-item">No results found</div>');
                    }
                });
            });

            $address_suggestions.on('click', 'a', function(e) {
                e.preventDefault();
                var data = $(this).data();

                $('#shop_name').val(data.name);
                $('#shop_address').val(data.address);
                $('#shop_latitude').val(data.lat);
                $('#shop_longitude').val(data.lng);

                // $('#shop_preview').attr('src', data.image || '').toggle(!!data.image);
                $('#blah').attr('src', data.image || '').toggle(!!data.image);
                $('#shop_image_from_google').val(data.image);
                $address_suggestions.empty().hide();
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('#shop_address, #address_suggestions').length) {
                    $address_suggestions.empty().hide();
                }
            });
        });
    </script>
@endsection
